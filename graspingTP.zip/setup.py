from setuptools import setup

setup(name='pandapybullet_minimal',
      version='0.0.1',
      install_requires=['pybullet']
)  
